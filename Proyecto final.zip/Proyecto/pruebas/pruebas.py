"""import clases.bus as bus

b1 = bus.Bus()

print("datos del bus")
nbus = "121"
nchofer = "Carlos"
b1.set_bus_num(nbus)
b1.set_nombre_chofer(nchofer)
b1.insertardatos() """

"""import clases.paradas as prd

p1 = prd.Paradas()

lugar = "Valledupar"
p1.set_lugar_parada(lugar)
#print(p1.lugar_parada)
p1.insertardatos()"""

"""import clases.Horario as hr

h1 = hr.Horario()

hll ="12:20"

hs = "12:32"

h1.set_h_llegada(hll)
h1.set_h_salida(hs)
#print(h1.h_llegada, h1.h_salida)
h1.insertardatos()"""

"""import clases.fecha as fc

fc1 = fc.Fecha()
fecha = "02/10/2022"
fc1.set_fecha(fecha)
#print(fc1.fecha)
fc1.ingresardatos()"""